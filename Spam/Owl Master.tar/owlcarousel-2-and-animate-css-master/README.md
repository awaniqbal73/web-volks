# [Owl Carousel customization with animated caption using animate.css](http://www.sagungautam.com.np/)

### Owl Carousel 2 : https://owlcarousel2.github.io/OwlCarousel2/
### Animate CSS : https://daneden.github.io/animate.css/

Video Tutorial : [Youtube](https://twitter.com/gudboisgn).